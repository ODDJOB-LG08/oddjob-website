document.addEventListener('DOMContentLoaded', function() {
  const form = document.querySelector('.contact form');
  const success = document.getElementById('form-success');

  if (form && success) {
    form.addEventListener('submit', function(e) {
      // Netlify handles the actual submission, but this is for instant feedback
      setTimeout(() => {
        form.classList.add('hidden');
        success.classList.remove('hidden');
      }, 500); // delay to mimic form submission
    });
  }
});