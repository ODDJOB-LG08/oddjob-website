# Odd-Job Logistics - Line Striping Services Website

## Features
- Modern, mobile-friendly design
- Service overview, pricing, and features
- Contact/quote request form (Netlify Forms ready)
- Easy to deploy to Netlify or GitHub Pages

## Local Development
1. Clone or download this repository.
2. Open `index.html` in your browser to preview.

## Deploying to Netlify
1. Go to [Netlify](https://netlify.com).
2. Click "Add new site" > "Import an existing project".
3. Connect your GitHub repository, or drag-and-drop the project folder.
4. Netlify will recognize the static site and deploy it automatically.
5. Form submissions will appear in your Netlify dashboard (no backend needed).

## Deploying to GitHub Pages
1. Push your project to a GitHub repository.
2. In your repo, go to Settings > Pages.
3. Set branch to `main` (or `master`) and folder to `/root`.
4. Your site will be live at `https://yourusername.github.io/reponame/`.
5. **Note:** The contact form won’t work on GitHub Pages unless you use an external form service (like Formspree).

## Customizing
- Update services, pricing, or contact info in `index.html`.
- Edit styles in `styles.css` for colors or layout tweaks.

---

© 2025 Odd-Job Logistics